﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Threading;
using System.Text;

namespace CybersecurityAwarenessBot
{
    class Program
    {
        static Dictionary<string, string> responses = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)//(w3schools,n/a)
        {
            { "hello", "Hello there! How can I help you with cybersecurity today?" },
            { "hi", "Hi there! Ready to learn about staying safe online?" },
            { "how are you", "I'm functioning perfectly! Ready to assist you with cybersecurity information." },
            { "what's your purpose", "I'm designed to help South African citizens understand cybersecurity risks and how to stay safe online." },
            { "what can i ask you about", "You can ask me about password safety, phishing, safe browsing, malware protection, and other cybersecurity topics!" },
            { "password", "Strong passwords are essential! Use a mix of upper and lowercase letters, numbers, and symbols. Avoid using personal information, and never reuse passwords across different accounts." },
            { "password safety", "To keep your passwords safe: 1) Use unique passwords for each account 2) Make them at least 12 characters long 3) Consider using a password manager 4) Enable two-factor authentication when available." },
            { "password manager", "Password managers securely store your passwords in an encrypted vault. They can generate strong passwords and automatically fill them in websites and apps!" },
            { "phishing", "Phishing attacks try to trick you into revealing personal information. Always check the sender's email address, don't click suspicious links, and never provide personal information unless you're sure the request is legitimate." },
            { "suspicious email", "If you receive a suspicious email: 1) Don't click any links 2) Don't download attachments 3) Don't reply with personal information 4) Report it as spam or phishing to your email provider." },
            { "suspicious link", "Before clicking links: 1) Hover over them to see the actual URL 2) Check if the URL matches the expected website 3) Look for HTTPS in the address 4) When in doubt, navigate to the website directly instead of clicking the link." },
            { "safe browsing", "For safe browsing: 1) Keep your browser updated 2) Use secure connections (HTTPS) 3) Be careful what you download 4) Use privacy-focused browser extensions 5) Clear your browser data regularly." },
            { "public wifi", "When using public WiFi: 1) Avoid accessing sensitive accounts 2) Use a VPN for encryption 3) Disable file sharing 4) Forget the network when done 5) Consider using your mobile data for sensitive transactions instead." },
            { "vpn", "A VPN (Virtual Private Network) encrypts your internet connection, protecting your data from being intercepted. It's especially important when using public WiFi networks." },                     
            { "malware", "Malware is malicious software designed to damage or gain unauthorized access to your system. Protect yourself with updated antivirus software, avoid suspicious downloads, and keep your operating system updated." },
            { "antivirus", "Antivirus software helps detect and remove malware. Keep it updated, run regular scans, and pay attention to its warnings about suspicious files or websites." },
            { "updates", "Software updates often contain security patches. Always keep your operating system, apps, and browsers updated to protect against known vulnerabilities." },                      
            { "social engineering", "Social engineering attacks manipulate people into breaking security procedures. Be skeptical of unexpected requests, verify identities through official channels, and never share sensitive information without verification." },                       
            { "south africa", "South Africa has seen a rise in cybercrime, including banking fraud, identity theft, and ransomware attacks. The Cybercrimes Act was introduced to help combat these issues." },
            { "cybercrimes act", "The Cybercrimes Act in South Africa criminalizes various types of cybercrime and gives law enforcement agencies investigative powers to combat cybercrime." },
            { "help", "I can explain: password safety, phishing, secure browsing, malware, social engineering, and South Africa's Cybercrimes Act." },
            { "exit", "exit" }
        };

        static string userName;//(w3schools,n/a)
        const int ConsoleWidth = 80;

        static void Main(string[] args)//(w3schools,n/a)
        {
            Console.Title = "SA Cybersecurity Awareness Bot";
            Console.OutputEncoding = Encoding.UTF8;
            Console.WindowWidth = ConsoleWidth;
            Console.BufferWidth = ConsoleWidth;//(w3schools,n/a)

            DisplayLogo();
            PlayVoiceGreeting();
            ShowWelcomeMessage();
            GetUserName();
            RunChatbot();
        }

        static void DisplayLogo()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(@" 
  ______     __  __     ______     ______     ______     ______     ______     ______    
/\  ___\   /\ \_\ \   /\  == \   /\  ___\   /\  == \   /\  ___\   /\  ___\   /\  ___\   
\ \ \____  \ \____ \  \ \  __<   \ \  __\   \ \  __<   \ \___  \  \ \  __\   \ \___  \  
 \ \_____\  \/\_____\  \ \_____\  \ \_____\  \ \_\ \_\  \/\_____\  \ \_____\  \/\_____\ 
  \/_____/   \/_____/   \/_____/   \/_____/   \/_/ /_/   \/_____/   \/_____/   \/_____/ 
    _______     _______   _______    ______     ______     ______    __   __     ______    ______     ______    
   /\  __ \   /\  \  \  /\  \  \  /\  __ \   /\  == \   /\  ___\  /\ ^\  \_\   /\  ___\  /\  ___\   /\  ___\   
   \ \  __ \  \ \  \  \ \ \  \  \ \ \  __ \  \ \  __<   \ \  __\  \ \ \__\ \   \ \  __\  \ \___  \  \ \___  \  
    \ \_\ \_\  \ \_____\ \ \_____\ \ \_\ \_\  \ \_____\  \ \_____\ \ \_____\   \ \_____\ \/\_____\  \/\_____\ 
     \/_/\/_/   \/_____/  \/_____/  \/_/\/_/   \/_____/   \/_____/  \/_____/    \/_____/  \/_____/   \/_____/ 

╔════════════════════╗
║     ████████       ║
║    ██      ██      ║
║    ██  SAFE ██     ║
║    ██      ██      ║
║     ████████       ║
║        ██          ║
║        ██          ║
╚════════════════════╝
*** PROTECTING SOUTH AFRICANS ONLINE ***
*** DEVELOPED BY THE DEPARTMENT OF CYBERSECURITY ***");
            Thread.Sleep(2000);
            Console.ResetColor();
        }//(elshan,2017)

        static void PlayVoiceGreeting()
        {
            try
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\n[Playing security greeting tone...]");//(lee k, 2017)

                var soundPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "greeting.wav");
                SoundPlayer player = new(soundPath);
                player.Play();//(kozlov K, 2024)
            }
            finally
            {
                Console.ResetColor();
            }
        }

        static void ShowWelcomeMessage()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            DrawBox("Welcome to the South African Cybersecurity Awareness Chatbot");//(lee k, 2017)
            Console.ResetColor();//(w3schools,n/a)
        }

        static void GetUserName()
        {
            Console.Write("\nPlease enter your name: ");//(lee k, 2017)
            userName = Console.ReadLine();

            while (string.IsNullOrWhiteSpace(userName))
            {
                Console.Write("Please enter a valid name: ");//(lee k, 2017)
                userName = Console.ReadLine();
            }

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine($"\nNice to meet you, {userName}! I'm here to help you stay secure online.");//(lee k, 2017)
            Console.WriteLine("Type 'help' for options or 'exit' to quit.");//(lee k, 2017)
            Console.ResetColor();
        }

        static void RunChatbot()
        {
            while (true)
            {
                ShowInputPrompt();
                string input = Console.ReadLine().Trim();

                if (string.IsNullOrWhiteSpace(input)) continue;

                string response = GetResponse(input);
                if (response.ToLower() == "exit")
                {
                    ExitProcedure();
                    return;
                }

                ShowResponse(response);//(w3schools,n/a)
            }
        }

        static string GetResponse(string userInput)
        {
            foreach (var key in responses.Keys)
            {
                if (userInput.Contains(key, StringComparison.OrdinalIgnoreCase))
                {
                    return responses[key];
                }
            }
            return "I'm not sure about that. Type 'help' for cybersecurity topics.";//(lee k, 2017)
        }

        static void ShowInputPrompt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n┌─────────────┐");
            Console.WriteLine("│ Your query: │");
            Console.WriteLine("└─────────────┘");//(elshan,2017)
            Console.Write("> ");//(lee k, 2017)
            Console.ResetColor();
        }

        static void ShowResponse(string response)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n┌─────────────────────────────────────────────────┐");
            Console.WriteLine("│ CyberBot:                                       │");
            Console.WriteLine("├─────────────────────────────────────────────────┤");//(elshan,2017)

            foreach (var line in WrapText(response, 47))
            {
                Console.Write("│ ");
                foreach (char c in line)
                {
                    Console.Write(c);
                    Thread.Sleep(25);
                    Console.Out.Flush();
                }
                Console.WriteLine(new string(' ', 47 - line.Length) + " │");//(w3schools,n/a)
            }

            Console.WriteLine("└─────────────────────────────────────────────────┘");//(elshan,2017)
            Console.ResetColor();
        }

        static void DrawBox(string text)
        {
            int width = ConsoleWidth - 10;
            Console.WriteLine($"\n╔{new string('═', width)}╗");
            Console.WriteLine($"║{text.PadLeft((width + text.Length) / 2).PadRight(width)}║");
            Console.WriteLine($"╚{new string('═', width)}╝");
        }

        static IEnumerable<string> WrapText(string text, int maxWidth)
        {
            string[] words = text.Split(' ');
            StringBuilder currentLine = new StringBuilder();

            foreach (string word in words)
            {
                if (currentLine.Length + word.Length + 1 > maxWidth)
                {
                    yield return currentLine.ToString();
                    currentLine.Clear();
                }
                currentLine.Append(word + " ");
            }

            if (currentLine.Length > 0)
                yield return currentLine.ToString().TrimEnd();
        }//(w3schools,n/a)

        static void ExitProcedure()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine($"\nThank you for using the Cybersecurity Bot, {userName}!");//(lee k, 2017)
            Console.WriteLine("Press any key to exit...");//(lee k, 2017)
            Console.ResetColor();
            Console.ReadKey();
        }


        //CODE ATTRIBUTION:
        //(W3SCHOOLS,N/A, C# STRINGS  online:https://www.w3schools.com/cs/cs_strings.phpACCESSED accessed :20/04/25)
        //(lee k, 2017, displaying messages in c# accessed online:https://stackoverflow.com/questions/42433907/how-to-display-a-message-while-program-is-running accessed: 20/04/2025)
        //(elshan,2017 ascii char, online:https://stackoverflow.com/questions/34328680/print-ascii-char-on-the-console-in-c-sharp accessed: 20/04/25)
        //(kozlov k,2024 soundplay c# online:https://stackoverflow.com/questions/3502311/how-to-play-a-sound-in-c-net accessed: 20/04/2025)

    }
}
